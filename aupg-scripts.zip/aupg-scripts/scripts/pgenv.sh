#!/bin/bash
echo 'setting up pg env'
export PGHOST=
export PGUSER= 
export PGPASSWORD=
export PGDATABASE=
