begin;
select hr.add_employee_data(5);
end;
