#!/bin/bash
export PGHOST=xxxxxxxxxxxxx.us-west-2.rds.amazonaws.com
export PGUSER=dbadmin 
export PGPASSWORD=password
export PGDATABASE=postgres
